//____________WISHLISTALERT________________
import React from 'react'
import './WishListAlert.css'
//__________________________
const WishListAlert = () => {


  return (
    <div className='wishlist-alert' >تم اضافة المنتج فى قائمة المفضلة الخاصة بك</div>
  )
}

export default WishListAlert